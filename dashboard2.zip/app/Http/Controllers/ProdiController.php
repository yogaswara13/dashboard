<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProdiController extends Controller
{
    public function detailProdi(Request $request){
        $select_data = "kode_hash, kode, kode_fakultas, fakultas, singkatan_fakultas, kode_unit_kerja, nama, prodi, singkatan_prodi, stat_prodi";
        $angkatan = session('angkatan_query');
        $angkatan_ams = angkatanAms();
        $data['menu'] = "dashboard";
        $data['subMenu'] = "Detail Prodi";
        $data['detail_prodi'] = getData('/master/prodi', "where=kode_hash='$request->id'", 0, $select_data, '')->result[0];

        $data['jml_mahasiswa'] = getTotalData('/mahasiswa/count', "where=kode_fakultas='UNPAS3' AND kode_prodi='$request->kode' AND mulai_smt IN($angkatan) AND tgl_keluar IS NOT NULL", 0, NULL, 'KODE');

        $data['jml_dosen'] = getTotalData('/dosen/count', "where=kode_fakultas='UNPAS3' AND kode_hash_prodi='$request->id'") ;

        $data['jml_alumni'] = getTotalData('/mahasiswa/wisuda', "where=FakultasID=3 AND statusMahasiswa='Lulus' AND ProdiID='$request->kode'");

        $all_ipk = getData('/mahasiswa', "where=kode_fakultas='UNPAS3' AND kode_prodi='$request->kode' AND mulai_smt IN($angkatan) AND tgl_keluar IS NOT NULL", $data['jml_mahasiswa'], "ipk", '')->result;

        $total_ipk = 0;
        foreach ($all_ipk as $item) {
            $total_ipk += $item->ipk;
        }

        $data['avg_ipk'] = number_format( ($total_ipk * 4 / $data['jml_mahasiswa']), 2, '.', '' ) ;


        echo "Rumus : ";
        echo "<br>" ;
        echo "Rata-rata IPK = jumlah_ipk / jumlah_mhs" ;
        echo "<br> $total_ipk / " . $data['jml_mahasiswa'] . " = " . $total_ipk/$data['jml_mahasiswa'] ;

        echo "<br><br>" ;
        echo "Rata-rata IPK = (jumlah_ipk / 4) / jumlah_mhs" ;
        echo "<br> ($total_ipk / 4) / " . $data['jml_mahasiswa'] . " = " . ($total_ipk/4)/$data['jml_mahasiswa'] ;

        echo "<br><br>" ;
        echo "Rata-rata IPK = (jumlah_ipk * jumlah_mhs) / 4" ;
        echo "<br> ($total_ipk * " . $data['jml_mahasiswa'] . ") / 4 = " . ($total_ipk*$data['jml_mahasiswa']) / 4 ;

        echo "<br><br>" ;
        echo "Rata-rata IPK = (jumlah_ipk * 4) / jumlah_Mhs" ;
        echo "<br> ($total_ipk * 4 ) / " . $data['jml_mahasiswa'] . " = " . ($total_ipk* 4) / $data['jml_mahasiswa'] ;


        // $data['ams_mhs'] = getTotalData('/mahasiswa/count', "where=kode_fakultas='UNPAS3' AND kode_prodi='$request->kode' AND mulai_smt=$angkatan_ams AND tgl_keluar IS NOT NULL", 0, NULL, 'KODE');

        // return view('pages.detail.jurusan.detail-prodi', $data);
    }
}
